#fça um programa que leia um nome e imprima quantas letreas tem esse nome
#print(list(range(9999999)))

nome = 5
qut=0

if l in nome :
        qut = qut+1
        print(qut)