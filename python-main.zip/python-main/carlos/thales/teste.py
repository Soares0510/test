with open ("Manipulacao_de_arquivo.py","r") as lista :
    couteudo = lista.read()
    print(couteudo)