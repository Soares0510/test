#with serve paara qualque tipo de manipulação de arquivo
with open ("..//CARLOS//thales//lista.txt","w") as arquivo:
   arquivo.write('Este e um arquivo de exemploM2')
   