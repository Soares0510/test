#faça um lista,dicionario e um tupla
lista = [1,2,3,4,5,6]
print(lista)
lista.append(7)
print(lista)
lista.insert(6,9)
print(lista)
lista.remove(4)
print(lista)
lista.pop(3)
print(lista)
print("\n\n",30*"-")

tupla = (1,2,3,4,5,6)
print(tupla)

a=tupla.index(2)
print(tupla)

tupla.count(2)
print(tupla)

dicionario = {"nome":'carlos',"idade":'16'}

dicionario.keys()
print(dicionario)






















