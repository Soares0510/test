import modulacao

#Programa principal 
num= int(input('Digite um numero inteiro:'))
modulacao.imprimir_fatorial(num)


