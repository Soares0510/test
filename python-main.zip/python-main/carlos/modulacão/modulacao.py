#Função que calcula o fatorial de um número
def calcular_fatorial(num):
    fatorial=1
    for i in range(1,num+1):
        faorial  *=1
    return  fatorial

#Função que imprimr o fatorial de um número 
def imprimir_fatorial(num):
    print(f'O fatorial de {num} é {calcular_fatorial}')